package analysis

import (
	"fmt"
	"regexp"
)

type CVItem struct {
	Name   string
	Values []string
}

type CVGroup struct {
	Name  string
	Items []CVItem
}

type Resume struct {
	Items  []CVItem
	Groups [] CVGroup
}

func Analysis(content string) Resume {
	//fmt.Println("++++++++++[start]+++++++++++")
	var cv Resume
	codingBody := formatContent([]rune(content))
	position := 0
	for position < len(codingBody) {
		character := codingBody[position]
		//		if position < 100 {
		//			matchName(position, codingBody, &cv)
		//		}
		//fmt.Printf("[1] position:%d,coding:%d\n", position, character)
		if items, ok := TagMap[character]; ok {
			match := false
			var tag Tag
			if position, match = matchItems(position, codingBody, items, &tag); match {
				//fmt.Println(match)
				cv.Items = append(cv.Items, CVItem{tag.name, []string{tag.content}})
			}
		}
		if position < 200 {

			position = matchDate(position, codingBody, &cv)
		}
		position++
	}
	matchName(0, codingBody[:150], &cv)
	//fmt.Println(cv)
	return cv
}

var dateTags []rune = []rune{32, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 24180, 26085, 26376}

func matchDate(position int, text []rune, cv *Resume) int {
	start := position
	i := 0
	for binSearch(dateTags, text[position]) {
		if text[position] == 32 && i == 0 {
			break
		}
		position++
		i++
	}
	if i > 0 {
		//fmt.Println("时间====================")
		if position-start > 5 {
			cv.Items = append(cv.Items, CVItem{TagList[2], []string{string(text[start:position])}})
		}
		fmt.Println(string(text[start:position]))
	}
	return position
}

var unNameTags []rune = []rune{9, 10, 13, 32, 124}

func matchName(position int, text []rune, cv *Resume) int {
	newLine:=true
	start := position
	for position < len(text) {
		i := 0
		for position < len(text) && binSearch(unNameTags, text[position]) {
			if text[position]==10{
				newLine=true
			}
			position++
		}
		start = position
		for position < len(text) && !binSearch(unNameTags, text[position]) {
			position++
			i++
		}
		if i >= 2 && i<=4 && newLine {
			fmt.Println(text[start:position])
			name := string(text[start:position])
			fmt.Println("姓名:", name)
			if m, _ := regexp.MatchString("^[\\x{4e00}-\\x{9fa5}]+$", name); m {
				cv.Items = append(cv.Items, CVItem{TagList[0], []string{string(text[start:position])}})
				break
			}
		}
		newLine=false

	}

	return position
}

func matchItems(position int, text []rune, items []TMapItem, tag *Tag) (int, bool) {
	//match := true
	for _, item := range items {
		match := true
		curr := position
		for _, sub := range item.Body {
			curr++
			//fmt.Printf("[2] position:%d,coding:%d,curr=%d,sub=%d\n", position, text[curr],curr,sub)
			if sub != text[curr] {
				//				if sub == 13 || sub == 10 {
				//					curr--
				//					break
				//				}
				//				if sub == 65306 && text[curr] == 58 {
				//					continue
				//				}
				match = false
				break
			}
		}
		if match {
			tag.id = item.TagIndex
			tag.name = TagList[item.TagIndex]
			//fmt.Println(item.TagIndex)
			//fmt.Println("[1] atchitems()"+TagList[item.TagIndex])
			if content, currPosition, ok := TagFilters[item.Type].Extract(text, position, curr); ok {
				tag.content = content
				return currPosition, match
			}else {
				return position, false
			}
		}
	}
	return position, false
}

func matchItem(position int, text []rune, items []TMapItem) (int, bool) {
	//match := true

	for i := 0; i < len(items); i++ {
		item := items[i]
		match := true
		curr := position
		for _, sub := range item.Body {
			curr++
			//fmt.Printf("[2] position:%d,coding:%d,curr=%d,sub=%d\n", position, text[curr],curr,sub)
			if sub != text[curr] {
				//				if sub == 13 || sub == 10 {
				//					curr--
				//					break
				//				}
				//				if sub == 65306 && text[curr] == 58 {
				//					break
				//				}
				match = false
				break
			}
		}
		//fmt.Println(match)
		if match {
			previous := text[position - 1:position][0]
			behind := text[curr + 1:curr + 2][0]
			end := text[curr:curr + 1][0]
			//	fmt.Printf("previous=%d,behind=%s\n",previous,string(text[curr+1:curr + 2]))
			//	fmt.Printf("content=%s\n",string(text[start:curr+1]))
			if binSearch(spaceSymbol, previous) && (binSearch(spaceSymbol, behind) || (end == 58 || end == 65306)) {
				return curr, match
			}

		}
	}
	return position, false
}
