// REVU - whitebox testing of internal comps -- OK.

package redis

import (
	"log"
	"testing"
)

func TestStub(t *testing.T) {
	/* feed the compiler */
}

/* --------------- KEEP THIS AS LAST FUNCTION -------------- */
func TestEnd_ct(t *testing.T) {
	log.Println("-- connection test completed")
}
